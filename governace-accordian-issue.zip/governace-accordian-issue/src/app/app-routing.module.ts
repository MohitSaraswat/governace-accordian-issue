import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { TableExpandableRowsExample  } from './table/table-expandable-rows-example.component';


const routes: Routes = [
  { path: '', component: TableExpandableRowsExample }
  // { path: '1', component: TableComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
